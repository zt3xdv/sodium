export function renderSidebar() {
  const sidebar = document.createElement('aside');
  sidebar.id = 'sidebar';
  sidebar.className = 'sidebar';
  
  const currentPath = window.location.pathname;
  
  const navItems = [
    { path: '/dashboard', icon: 'dashboard', label: 'Dashboard' },
    { path: '/profile', icon: 'person', label: 'Profile' },
    { path: '/settings', icon: 'settings', label: 'Settings' }
  ];
  
  sidebar.innerHTML = `
    <div class="sidebar-header">
      <a href="/dashboard" class="sidebar-brand">
        <span class="material-icons-outlined">bolt</span>
        <span class="brand-text">Sodium</span>
      </a>
    </div>
    
    <nav class="sidebar-nav">
      <ul class="nav-list">
        ${navItems.map(item => `
          <li class="nav-item">
            <a href="${item.path}" class="nav-link ${currentPath === item.path ? 'active' : ''}">
              <span class="material-icons-outlined">${item.icon}</span>
              <span class="nav-text">${item.label}</span>
            </a>
          </li>
        `).join('')}
      </ul>
    </nav>
    
    <div class="sidebar-footer">
      <div class="footer-content">
        <span class="version">v1.0.0</span>
      </div>
    </div>
  `;
  
  setTimeout(() => {
    const closeOnMobile = () => {
      if (window.innerWidth <= 768) {
        sidebar.classList.remove('open');
      }
    };
    
    sidebar.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', closeOnMobile);
    });
  }, 0);
  
  return sidebar;
}
